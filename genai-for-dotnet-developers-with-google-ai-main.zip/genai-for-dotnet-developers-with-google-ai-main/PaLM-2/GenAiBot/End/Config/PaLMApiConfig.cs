namespace GenAiBot.Config
{
    public class PaLMApiConfig
    {
        public string Project { get; set; }
        public string Location { get; set; }
        public string Model { get; set; }
        public string Publisher { get; set; }
        public string RegionEndpoint { get; set; }
    }
}