namespace GenAiBot.Config
{
    public class BotConfig
    {
        public string BotName { get; set; }
        public string Slogan { get; set; }
        public string Context { get; set; }
    }
}