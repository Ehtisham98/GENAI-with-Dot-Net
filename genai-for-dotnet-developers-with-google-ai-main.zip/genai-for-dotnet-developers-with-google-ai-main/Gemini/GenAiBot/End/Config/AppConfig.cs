namespace GenAiBot.Config
{
    public class AppConfig
    {
        public ApiConfig ApiConfig { get; set; }
        public ParameterConfig ParameterConfig { get; set; }
        public BotConfig BotConfig { get; set; }
    }
}