namespace GenAiBot.Models
{
    public class GenAiChatViewModel
    {
        
    }
}