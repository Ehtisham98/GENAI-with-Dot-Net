namespace VertexAISDKGemini
{
    public class MessageContent
    {
        public string Role { get; set; }
        public string Text { get; set; }
    }
}